<?php 
	/*Enter your API_KEY*/
	define("API_KEY", 'pKtgK/fhGpY-QgXMoZrRIRLLjUdmDhz25Ef0gTlAZn');

	/*You can enter mobile number here*/
	define("MOBILE", '');
 ?>
<footer class="footer-area section_gap">
        <div class="container" align="center">

    <h2 align="center" style="color:#fff"> Student Leave Management System</h2>
        </div>
    </footer>